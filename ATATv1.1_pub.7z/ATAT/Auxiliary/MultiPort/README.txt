You must manually populate your RHOSTS variable in the script.
You must manually populate your auxiliary module path in the script.
You must add the PORTS you wish to test the aux module against in the "MSF_AUX_target_ports.txt" file one port number per line.

usage:
chmod +x /path/to/file/MSF_AUX_bash_multi_port1.sh (this only needs to be done the first time you run it)
./MSF_AUX_bash_multi_port1.sh
