#!/bin/bash

inputfile=/home/w0rk/MSF_target_ports.txt

for PORT in $(cat $inputfile)
do
msfconsole -x "use auxiliary/scanner/rdp/rdp_scanner;\
set RHOSTS 10.225.138.165;\
set RPORT $PORT;\
run;\
exit"
done
